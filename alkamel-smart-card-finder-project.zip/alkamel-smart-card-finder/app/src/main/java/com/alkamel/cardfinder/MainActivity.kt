package com.alkamel.cardfinder

import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class MainActivity : ComponentActivity() {
    private lateinit var db: CardDb
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var category: Spinner
    private var cameraUri: Uri? = null
    private val categories = listOf("100 ريال", "200 ريال", "250 ريال", "500 ريال")

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importDocument(uri)
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) readImage(uri)
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) readImage(cameraUri!!)
        else showStatus("لم يتم التقاط صورة")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CardDb(this)
        buildScreen()
        refreshStats()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF4F7F5.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "الكامل – الباحث الذكي عن الكروت"
            textSize = 22f; gravity = Gravity.CENTER
            setTextColor(0xFF126B3A.toInt()); setPadding(4, 12, 4, 18)
        }
        root.addView(title)

        val intro = TextView(this).apply {
            text = "استورد ملفات الكروت، أو صوّر الكرت لقراءة رقمه والبحث عنه في المخزون."
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFF52645A.toInt())
        }
        root.addView(intro)

        category = Spinner(this)
        category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        root.addView(label("فئة الكروت التي تريد استيرادها"))
        root.addView(category)

        root.addView(actionButton("استيراد ملف TXT أو PDF") {
            openFile.launch(arrayOf("text/plain", "application/pdf", "application/octet-stream"))
        })
        root.addView(actionButton("تصوير الكرت بالكاميرا") { openCamera() })
        root.addView(actionButton("اختيار صورة من الهاتف") { pickImage.launch("image/*") })

        root.addView(label("البحث عن رقم كامل أو جزء من رقم"))
        searchBox = EditText(this).apply {
            hint = "مثال: 366365467"
            textSize = 18f
            singleLine = true
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            setPadding(12, 10, 12, 10)
        }
        root.addView(searchBox)
        root.addView(actionButton("ابحث في جميع الكروت") { searchCards() })

        status = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF24543A.toInt())
            setPadding(8, 14, 8, 14); gravity = Gravity.CENTER
        }
        root.addView(status)
        root.addView(label("النتائج / الأرقام المستخرجة"))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results)

        root.addView(actionButton("تحديث إحصائيات المخزون") { refreshStats() })
        root.addView(TextView(this).apply {
            text = "ملاحظة: قراءة الصور آلية وقد تخطئ في الأرقام المتشابهة. لا تعتمد أي رقم قبل مراجعته وتأكيده."
            textSize = 12f; setTextColor(0xFF7A5B22.toInt()); setPadding(6, 18, 6, 4)
        })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 15f; setTextColor(0xFF263B30.toInt())
        setPadding(4, 18, 4, 6)
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun showStatus(message: String) { status.text = message }

    private fun refreshStats() {
        val count = db.count()
        showStatus("إجمالي الأرقام المحفوظة: $count")
    }

    private fun openCamera() {
        try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val photo = File(dir, "card_${System.currentTimeMillis()}.jpg")
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photo)
            takePicture.launch(cameraUri)
        } catch (e: Exception) {
            showStatus("تعذر فتح الكاميرا: ${e.localizedMessage}")
        }
    }

    private fun importDocument(uri: Uri) {
        val cat = categories[category.selectedItemPosition]
        lifecycleScope.launch {
            showStatus("جارٍ استيراد الملف...")
            val name = queryName(uri)
            try {
                val numbers = withContext(Dispatchers.IO) {
                    when {
                        name.lowercase(Locale.ROOT).endsWith(".pdf") ||
                            contentResolver.getType(uri) == "application/pdf" -> readPdfNumbers(uri, cat, name)
                        else -> readTextNumbers(uri, cat, name)
                    }
                }
                showStatus("اكتمل الاستيراد: أضيف ${numbers} رقم إلى فئة $cat")
                refreshStats()
            } catch (e: Exception) {
                showStatus("تعذر استيراد الملف: ${e.localizedMessage}")
            }
        }
    }

    private fun queryName(uri: Uri): String {
        return contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else "ملف مستورد"
        } ?: "ملف مستورد"
    }

    private fun readTextNumbers(uri: Uri, cat: String, name: String): Int {
        val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: throw IllegalStateException("تعذر قراءة الملف")
        val normalized = normalizeDigits(text)
        val matches = Regex("(?<!\\d)\\d{11}(?!\\d)").findAll(normalized).map { it.value }.toList()
        return db.insertMany(matches, cat, name, 0)
    }

    private suspend fun readPdfNumbers(uri: Uri, cat: String, name: String): Int {
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("تعذر فتح PDF")
        var added = 0
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    val scale = minOf(2.0, 1800.0 / maxOf(page.width, page.height))
                    val bitmap = Bitmap.createBitmap(
                        (page.width * scale).toInt().coerceAtLeast(1),
                        (page.height * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    page.close()
                    val text = recognize(InputImage.fromBitmap(bitmap, 0)).text
                    bitmap.recycle()
                    val nums = Regex("(?<!\\d)\\d{11}(?!\\d)").findAll(normalizeDigits(text))
                        .map { it.value }.toList()
                    added += db.insertMany(nums, cat, name, i + 1)
                    withContext(Dispatchers.Main) { showStatus("قراءة PDF: الصفحة ${i + 1} من ${renderer.pageCount}") }
                }
            }
        }
        return added
    }

    private fun readImage(uri: Uri) {
        lifecycleScope.launch {
            try {
                showStatus("جارٍ قراءة الصورة...")
                val image = InputImage.fromFilePath(this@MainActivity, uri)
                val text = recognize(image).text
                val digits = normalizeDigits(text)
                val candidates = Regex("\\d{7,15}").findAll(digits).map { it.value }.distinct().toList()
                showOcrCandidates(candidates, text)
            } catch (e: Exception) {
                showStatus("تعذرت قراءة الصورة: ${e.localizedMessage}")
            }
        }
    }

    private suspend fun recognize(image: InputImage): Text =
        suspendCancellableCoroutine { cont ->
            val client = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            client.process(image)
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
                .addOnCompleteListener { client.close() }
        }

    private fun normalizeDigits(input: String): String {
        val out = StringBuilder()
        input.forEach { ch ->
            when (ch) {
                in '٠'..'٩' -> out.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> out.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> out.append(ch)
            }
        }
        return out.toString()
    }

    private fun showOcrCandidates(candidates: List<String>, rawText: String) {
        results.removeAllViews()
        if (candidates.isEmpty()) {
            showStatus("لم أستطع قراءة رقم واضح. جرّب صورة أقرب وإضاءة أفضل.")
            return
        }
        showStatus("استخرجت ${candidates.size} احتمالاً. اختر الرقم الصحيح أو ابحث به.")
        candidates.forEach { candidate ->
            val matches = db.search(candidate)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 10, 12, 10)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            row.addView(TextView(this).apply {
                text = candidate; textSize = 20f; gravity = Gravity.CENTER
                setTextColor(0xFF174D2D.toInt())
            })
            row.addView(Button(this).apply {
                text = "البحث بهذا الاحتمال"
                setOnClickListener {
                    searchBox.setText(candidate)
                    displayMatches(db.search(candidate), candidate)
                }
            })
            row.addView(Button(this).apply {
                text = "تأكيد الرقم وحفظه"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("تأكيد رقم الكرت")
                        .setMessage("هل تؤكد أن الرقم هو:\n$candidate ؟")
                        .setNegativeButton("مراجعة", null)
                        .setPositiveButton("تأكيد") { _, _ ->
                            db.insertMany(listOf(candidate), categories[category.selectedItemPosition], "صورة ملتقطة", 0)
                            showStatus("تم حفظ الرقم بعد تأكيدك")
                            displayMatches(db.search(candidate), candidate)
                        }.show()
                }
            })
            results.addView(row)
        }
    }

    private fun searchCards() {
        val q = normalizeDigits(searchBox.text.toString()).filter { it.isDigit() }
        if (q.length < 3) {
            showStatus("أدخل 3 أرقام على الأقل للبحث")
            return
        }
        displayMatches(db.search(q), q)
    }

    private fun displayMatches(matches: List<CardRecord>, query: String) {
        results.removeAllViews()
        showStatus("نتائج البحث عن $query: ${matches.size}")
        if (matches.isEmpty()) {
            results.addView(TextView(this).apply {
                text = "لم يتم العثور على تطابق في المخزون المستورد."
                setPadding(8, 12, 8, 12)
            })
        }
        matches.forEach { item ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 10, 12, 10)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            box.addView(TextView(this).apply {
                text = item.number; textSize = 20f; setTextColor(0xFF126B3A.toInt())
            })
            box.addView(TextView(this).apply {
                text = "الفئة: ${item.category}   |   الملف: ${item.source}   |   الصفحة: ${if (item.page > 0) item.page else "—"}"
                textSize = 12f; setTextColor(0xFF59665E.toInt())
            })
            box.addView(Button(this).apply {
                text = "نسخ الرقم"
                setOnClickListener {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("رقم الكرت", item.number))
                    showStatus("تم نسخ الرقم")
                }
            })
            results.addView(box)
        }
    }
}

data class CardRecord(
    val number: String, val category: String, val source: String, val page: Int
)

class CardDb(context: android.content.Context) :
    android.database.sqlite.SQLiteOpenHelper(context, "alkamel_cards.db", null, 1) {

    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE cards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number TEXT NOT NULL,
                category TEXT NOT NULL,
                source TEXT NOT NULL,
                page INTEGER NOT NULL DEFAULT 0,
                UNIQUE(number, category, source, page)
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_cards_number ON cards(number)")
    }

    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertMany(numbers: List<String>, category: String, source: String, page: Int): Int {
        val db = writableDatabase
        var added = 0
        db.beginTransaction()
        try {
            numbers.distinct().forEach { number ->
                if (number.length in 7..15 && number.all { it.isDigit() }) {
                    val values = ContentValues().apply {
                        put("number", number); put("category", category)
                        put("source", source); put("page", page)
                    }
                    if (db.insertWithOnConflict("cards", null, values, android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE) != -1L)
                        added++
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return added
    }

    fun search(query: String): List<CardRecord> {
        val cursor = readableDatabase.rawQuery(
            "SELECT number, category, source, page FROM cards WHERE number LIKE ? ORDER BY CASE WHEN number=? THEN 0 ELSE 1 END, number LIMIT 200",
            arrayOf("%$query%", query)
        )
        val out = mutableListOf<CardRecord>()
        cursor.use {
            while (it.moveToNext()) out.add(CardRecord(it.getString(0), it.getString(1), it.getString(2), it.getInt(3)))
        }
        return out
    }

    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM cards", null).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }
}
